

<?php
function write_footer()
{
	?>
<footer>
<div id="footer" class="footer">
			<p><img src="gofav25.png" alt="My favicon" /></p>
			
				<div id='footermenu'class="footermenu">
					<table >
						<tr>
							<td>
								<script type = "text/javascript">
									var now = new Date();
									document.write("<p>" +now+"</p>");
									var time = "AM";
									
									
								 </script>
								  
							</td>
						</tr>
					</table>
					
				</div>
			
		</div>
</footer>
	<?php
}
?>