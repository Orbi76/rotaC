<?php
function write_navbar()
{
	?>
	<div id="nav">
	<ul id="navbar">
  		<li><a href="index.php">Home</a></li>
  		<li><a href="asearchh.php">Search venues</a></li>
 		<li><a href="asignuph.php">Sign Up!</a></li>
  		<li><a href="aloginh.php">Login</a></li>
	</ul>
	</div>
	<?php
}
?>
