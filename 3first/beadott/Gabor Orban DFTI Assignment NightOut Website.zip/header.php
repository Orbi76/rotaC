<?php
function write_header()
{
	?>
	<div id="header">
	<h1>Night Out in our City!</h1>
</div>
	<?php
}
?>
